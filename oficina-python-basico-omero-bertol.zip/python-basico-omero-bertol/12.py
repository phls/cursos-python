a, b = input().split()
a = int(a)
b = int(b)

x = list(map(int, input().split()))

print()
for i in x:
    print(i, end=" ")

print("\n")

print(a, "foi encontrado", x.count(a), "vezes")
print(b, "foi encontrado", x.count(b), "vezes")
