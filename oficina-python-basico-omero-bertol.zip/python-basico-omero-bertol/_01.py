def tabuada(n):
    for i in range(1, 11):
        print("%d X %d = %d" % (n, i, (n*i)))

    print()

def fatorial(n):
    f = 1
    for i in range(1, n+1):
        f = f * i

    return f


tabuada(7)
tabuada(5)

print()
                                
print("5! = ", fatorial(5))
print("6! = ", fatorial(6))
