a = int(input("Informe um valor: "))

print()

if (a < 0):
    print(a, "é um número negativo")
elif (a == 0):
    print(a, "é um número sem sinal")
else:
    print(a, "é um número positivo")
