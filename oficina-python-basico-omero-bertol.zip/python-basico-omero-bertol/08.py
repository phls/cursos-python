i = 0
while (i < 10):
    print(i)
    i = i + 1

print()

i = 5
while (i <= 50):
    print(i, end=" ")
    i = i + 5

print()
print()

i = 10
while (i >= 1):
    print(i, end=" ")
    i = i - 1
