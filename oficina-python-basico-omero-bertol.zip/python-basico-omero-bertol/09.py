for i in range(10):
    print(i)

print()

for i in range(5, 51, 5):
    print(i, end=" ")

print()
print()

for i in range(10, 0, -1):
    print(i, end=" ")
