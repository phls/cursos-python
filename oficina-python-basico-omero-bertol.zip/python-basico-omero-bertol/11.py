x = [i for i in range(10, 101, 10)]

print(x, "tamanho =", len(x))
print()

for i in range(len(x)):
    print("posição", i, "=", x[i])

print()
for i in reversed(x):
    print(i, end=" ")
    
print("\n\nFrutas: ", end="")
frutas = ["maçã", "uva", "pera", "banana"]
for item in frutas:
    print(item, end=" ")
