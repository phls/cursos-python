n = int(input("Informe um número inteiro: "))

print()

if ((n % 2) == 0):
    print(n, "é um número \"par\"")

if ((n % 2) == 1):
    print(n, "é um número \"ímpar\"")
