a = int(input("Informe o 1o. valor: "))
b = int(input("Informe o 2o. valor: "))

print()

if (a < b):
    print(a, "é menor do que", b)

if (a == b):
   print(a, "é igual a", b)

if (a > b):
   print(a, "é maior do que", b)
