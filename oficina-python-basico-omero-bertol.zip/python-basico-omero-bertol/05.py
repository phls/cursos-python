a = int(input("Informe o 1o. valor: "))
b = int(input("Informe o 2o. valor: "))

print()

if (a < b):
    print(a, "é menor do que", b)
else:
    if (a == b):
       print(a, "é igual a", b)
    else:
       print(a, "é maior do que", b)
