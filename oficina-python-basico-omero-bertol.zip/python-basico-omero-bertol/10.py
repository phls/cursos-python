import math

n = int(input("Informe um número inteiro: "))

print()

print(n, "elevado ao quadrado =", math.pow(n, 2))
print("Raiz quadrada de %d = %.2f" % (n, math.sqrt(n)))

print("2 elevado 5 =", math.pow(2, 5))
print("5! =", math.factorial(5))
print("|-10| =", abs(-10))
