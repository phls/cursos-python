a = int(input("Informe o 1o. valor: "))
b = int(input("Informe o 2o. valor: "))

print()

print(a, "+", b, "=", (a+b))
print(a, "-", b, "=", (a-b))
print(a, "*", b, "=", (a*b))
print(a, "/", b, "=", (a/b))
