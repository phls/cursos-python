# função que verifica se "n" é um número primo
def ehPrimo(n):
    for i in range(2, (n//2)+1, 1):
        if ((n % i) == 0):
            return(False) # tem divisor não é primo

    return(True)


# Módulo principal (main)
for n in range(1, 100):
    if (ehPrimo(n) == True):
        print(n, end=" ")
