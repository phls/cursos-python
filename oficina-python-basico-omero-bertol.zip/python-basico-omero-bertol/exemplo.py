# print: comando de saída
print(3 + 7)

a = 5
print(a * 2)
print(5 / 2)


'''
    estrutura de repetição "for": i - variável de controle
        mostra a mensagem "Alô mundo! fazendo a variável de controle "i"
        variar de 0 até 6
'''
for i in range(7):
    print(i, "Alô mundo!")


print(5 > 2)
print(7 // 2) # operador // realiza a divisão inteira
print(7 % 2)  # operador % calcula o resto da divisão
