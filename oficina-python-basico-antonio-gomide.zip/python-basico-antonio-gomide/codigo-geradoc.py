# -*- coding: utf-8 -*-
import arcpy, os, string, sys
import codecs
#import ReportLab modules (the ReportLab package must be installed)
from reportlab.platypus import BaseDocTemplate, Frame, NextPageTemplate, PageBreak, PageTemplate, Paragraph, Table
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics 
from reportlab.pdfbase.ttfonts import TTFont
#
from reportlab.pdfgen import canvas
path = os.path.dirname(sys.argv[0])
pdfmetrics.registerFont(TTFont('Arial', 'Arial.ttf'))
print ('Iniciando...')
## separador
def gerasep(c):
    c.setFont("Arial", 32)
    c.drawString(10,10, u"Python 101".encode('utf-8'))
    
#Read values from input dialog
#title = arcpy.GetParameterAsText(0)
title = "Material Curso linguagem Python"
#organization = arcpy.GetParameterAsText(1)
organization = "FTSL "

#Export the Title Page into a single page PDF
arcpy.AddMessage("    Updating Title Page ...")
titleMXD = arcpy.mapping.MapDocument(path + r"\6_TitlePage.mxd")
titleText = arcpy.mapping.ListLayoutElements(titleMXD, "TEXT_ELEMENT", "Title")[0]
titleText.text = title
arcpy.mapping.ExportToPDF(titleMXD, path + r"\1_TitlePage.pdf")
del titleMXD



#Append PDFs into final result
arcpy.AddMessage("    Compiling final output ...")
if os.path.exists(path + r"\Material_Python.pdf"):
	os.remove(path + r"\Material_Python.pdf")
finalPDF = arcpy.mapping.PDFDocumentCreate(path + r"\Material_Python.pdf")
finalPDF.appendPages(path + r"\1_TitlePage.pdf")
finalPDF.appendPages(path + r"\FTSL_Python_101.pdf")
c = canvas.Canvas('separador1.pdf')
gerasep(c)
c.showPage()
c.save()
finalPDF.appendPages(path + r"\separador1.pdf")
finalPDF.appendPages(path + r"\FTSL_Python_101_Strings.pdf")
finalPDF.appendPages(path + r"\separador1.pdf")
finalPDF.appendPages(path + r"\FTSL_Python_101_Functions.pdf")
##finalPDF.appendPages(path + r"\Python_ArcGIS.pdf")
finalPDF.appendPages(path + r"\separador1.pdf")
finalPDF.appendPages(path + r"\FTSL_Python_101_Functions.pdf")
finalPDF.appendPages(path + r"\separador1.pdf")
finalPDF.appendPages(path + r"\FTSL_Python_101_StdLibrary.pdf")
finalPDF.updateDocProperties(title, "ESRI", "Sample Map Book", "Map Book, index pages", "USE_THUMBS", "TWO_PAGE_LEFT")
finalPDF.saveAndClose()
print ('Iniciando...')
#clean up temporary PDF files
#os.remove(path + r"\1_TitlePage.pdf")
#os.remove(path + r"\Output\2_MapPages.pdf")
#os.remove(path + r"\Output\3_IndexPages.pdf")
print ('Terminando...')
arcpy.AddMessage("    Complete.")
